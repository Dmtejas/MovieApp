import { useRoutes } from "react-router-dom"
import LandingPage from "./pages/LandingPage"
import NotFound from "./components/NotFound";

const CustomRouter = () => {
    const customRoutes = useRoutes([
        {
            path: '/',
            element: <LandingPage />
        },
        {
            path: '*',
            element: <NotFound /> 
        }
    ])

    return customRoutes;
}

export default CustomRouter;

